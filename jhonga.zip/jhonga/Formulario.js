document.addEventListener("DOMContentLoaded", function () {
    const userData = localStorage.getItem("userData");

    if (!userData) {
        alert("Debes iniciar sesión primero.");
        window.location.href = "login.html";
        return;
    }

    const user = JSON.parse(userData);
    document.getElementById("nombre").value = user.name || "";
    document.getElementById("email").value = user.email || "";

    document.getElementById("user-form").addEventListener("submit", function (event) {
        event.preventDefault();

        const formData = {
            nombre: document.getElementById("nombre").value,
            email: document.getElementById("email").value,
            identificacion: document.getElementById("identificacion").value,
            telefono: document.getElementById("telefono").value,
            semestre: document.getElementById("semestre").value,
            programa: document.getElementById("programa").value
        };

        fetch("http://localhost:3000/guardar-usuario", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData)
        })
        .then(response => response.text())
        .then(data => {
            console.log("✅ Respuesta del servidor:", data);
            alert("Registro exitoso");
        })
        .catch(error => {
            console.error("❌ Error en la solicitud:", error);
            alert("Hubo un error al registrar");
        });
    });

    document.getElementById("identificacion").addEventListener("input", function () {
        this.value = this.value.replace(/\D/g, ""); // Solo números
    });

    document.getElementById("telefono").addEventListener("input", function () {
        this.value = this.value.replace(/\D/g, "").slice(0, 10); // Solo números y máx. 10 dígitos
    });
});
