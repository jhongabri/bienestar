function handleCredentialResponse(response) {
    if (!response.credential) {
        console.error("No se recibió un token de Google.");
        return;
    }

    const responsePayload = parseJwt(response.credential);

    if (!responsePayload || !responsePayload.name || !responsePayload.email) {
        console.error("Error al obtener los datos del usuario.");
        return;
    }

    // Guardar datos en localStorage
    localStorage.setItem("userData", JSON.stringify({
        name: responsePayload.name,
        email: responsePayload.email,
        picture: responsePayload.picture
    }));

    // Redirigir al formulario
    window.location.href = "Formulario.html";
}

function parseJwt(token) {
    try {
        let base64Url = token.split('.')[1];
        let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        let jsonPayload = decodeURIComponent(atob(base64).split('').map(c =>
            '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
        ).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) {
        console.error("Error al decodificar el token:", e);
        return null;
    }
}

