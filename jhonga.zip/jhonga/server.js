const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// Conexión a la base de datos actualizada
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "jhon.arboleda1", // Cambia por tu contraseña
    database: "sistema_usuarios"
});

db.connect(err => {
    if (err) {
        console.error("❌ Error de conexión a MySQL:", err);
        return;
    }
    console.log("✅ Conectado a MySQL");
});

// Ruta para guardar usuarios
app.post("/guardar-usuario", (req, res) => {
    const { nombre, email, identificacion, telefono, semestre, programa } = req.body;
    const sql = "INSERT INTO usuarios (nombre, email, identificacion, telefono, semestre, programa) VALUES (?, ?, ?, ?, ?, ?)";

    db.query(sql, [nombre, email, identificacion, telefono, semestre, programa], (err, result) => {
        if (err) {
            console.error("❌ Error al insertar usuario:", err);
            return res.status(500).send("Error en el servidor");
        }
        res.status(200).send("✅ Usuario guardado con éxito");
    });
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log("🚀 Servidor corriendo en http://localhost:3000");
});
