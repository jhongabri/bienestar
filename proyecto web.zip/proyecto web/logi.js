function handleCredentialResponse(response) {
    // Decodificar el token de Google
    const data = jwt_decode(response.credential);
    console.log("Usuario autenticado:", data);

    // Obtener el correo del usuario
    const email = data.email;
    const allowedDomain = "@amigo.edu.co"; // Dominio permitido

    if (email.endsWith(allowedDomain)) {
        // Guardar datos del usuario en localStorage
        localStorage.setItem("user", JSON.stringify(data));

        // Redirigir a otra página (cámbialo por el HTML que tengas)
        window.location.href = "index.html";
    } else {
        // Mostrar mensaje de error si el dominio no es válido
        document.getElementById("error-message").style.display = "block";
    }
}

// Cargar la librería para decodificar JWT
function loadScript(url, callback) {
    let script = document.createElement("script");
    script.type = "text/javascript";
    script.src = url;
    script.onload = callback;
    document.body.appendChild(script);
}

// Cargar la librería jwt-decode
loadScript("https://cdnjs.cloudflare.com/ajax/libs/jwt-decode/3.1.2/jwt-decode.min.js", function() {
    console.log("JWT Decode Library Loaded.");
});
